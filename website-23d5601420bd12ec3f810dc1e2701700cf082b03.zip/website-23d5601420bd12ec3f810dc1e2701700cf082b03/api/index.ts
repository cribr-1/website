// @ts-ignore
import app from "../dist/server.cjs";
export default (app as any)?.default || app;
