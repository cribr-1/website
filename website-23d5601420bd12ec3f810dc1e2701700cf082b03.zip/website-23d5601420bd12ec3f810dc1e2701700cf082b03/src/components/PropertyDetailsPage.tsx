import React, { useState, useEffect } from "react";
import {
  ArrowLeft,
  Heart,
  Share2,
  CheckCircle2,
  MapPin,
  Building2,
  AlertTriangle,
  Star,
  ArrowRight
} from "lucide-react";
import { PremiumProperty, SavedHome } from "../types";
import { showToast } from "./CribrToast";
import { getFeaturedProperties } from "../data";
import {
  mapToWhitelistedProject,
  findMatchingProperty,
  getPropertyAsync
} from "../lib/projectDataMapper";
import ProjectOverviewContent from "./ProjectOverviewContent";
import ProjectAIAssistant from "./Project/ProjectAIAssistant";

interface PropertyDetailsPageProps {
  propertyIdOrSlug: string;
  onBack: () => void;
  onNavigateProperty: (slug: string) => void;
  savedHomes?: SavedHome[];
  onSaveHome?: (property: PremiumProperty) => void;
  onRemoveSaved?: (id: string) => void;
  onSaveProperty?: (property: any) => void;
  isSaved?: boolean;
  onAskAI?: (query: string) => void;
  onBookVisit?: (property: PremiumProperty) => void;
  onCompare?: (property: PremiumProperty) => void;
}

export default function PropertyDetailsPage({
  propertyIdOrSlug,
  onBack,
  onNavigateProperty,
  savedHomes = [],
  onSaveHome,
  onRemoveSaved,
  onSaveProperty,
  isSaved = false
}: PropertyDetailsPageProps) {
  const [resolvedProperty, setResolvedProperty] = useState<any | null>(() => {
    return findMatchingProperty(propertyIdOrSlug);
  });
  const [isSearchingAsync, setIsSearchingAsync] = useState(false);

  useEffect(() => {
    window.scrollTo({ top: 0, behavior: "smooth" });

    const syncFound = findMatchingProperty(propertyIdOrSlug);
    if (syncFound) {
      setResolvedProperty(syncFound);
      return;
    }

    let isMounted = true;
    setIsSearchingAsync(true);
    getPropertyAsync(propertyIdOrSlug).then((prop) => {
      if (isMounted) {
        setResolvedProperty(prop);
        setIsSearchingAsync(false);
      }
    });

    return () => {
      isMounted = false;
    };
  }, [propertyIdOrSlug]);

  const rawProperty = resolvedProperty;
  const allAvailableProperties = getFeaturedProperties();

  if (isSearchingAsync) {
    return (
      <div className="min-h-screen bg-[#FAFAFC] font-sans text-neutral-900 flex flex-col justify-between">
        <header className="sticky top-0 z-40 bg-white/90 backdrop-blur-md border-b border-neutral-200/80 px-6 py-4 flex items-center justify-between">
          <button
            onClick={onBack}
            className="flex items-center space-x-2 text-neutral-700 hover:text-neutral-950 font-bold text-xs transition-colors cursor-pointer"
          >
            <ArrowLeft className="w-4 h-4" />
            <span>Back to Explorer</span>
          </button>
          <span className="font-display font-black text-lg text-neutral-950">
            CRIBR
          </span>
        </header>

        <main className="max-w-xl mx-auto px-6 py-24 text-center space-y-4 flex-1 flex flex-col justify-center items-center">
          <div className="w-12 h-12 rounded-2xl bg-blue-50 border border-blue-200 text-blue-600 flex items-center justify-center animate-pulse">
            <Building2 className="w-6 h-6 animate-spin" />
          </div>
          <h2 className="text-xl font-bold font-display text-neutral-950">
            Locating Property Records...
          </h2>
          <p className="text-xs text-neutral-500 font-mono">
            Searching regulatory registries and master datasets for &ldquo;{propertyIdOrSlug}&rdquo;
          </p>
        </main>
      </div>
    );
  }

  if (!rawProperty) {
    return (
      <div className="min-h-screen bg-[#FAFAFC] font-sans text-neutral-900 flex flex-col justify-between">
        <header className="sticky top-0 z-40 bg-white/90 backdrop-blur-md border-b border-neutral-200/80 px-6 py-4 flex items-center justify-between">
          <button
            onClick={onBack}
            className="flex items-center space-x-2 text-neutral-700 hover:text-neutral-950 font-bold text-xs transition-colors cursor-pointer"
          >
            <ArrowLeft className="w-4 h-4" />
            <span>Back to Explorer</span>
          </button>
          <span className="font-display font-black text-lg text-neutral-950">
            CRIBR
          </span>
        </header>

        <main className="max-w-3xl mx-auto px-6 py-12 text-center space-y-8 flex-1 flex flex-col justify-center items-center">
          <div className="w-16 h-16 rounded-3xl bg-amber-50 border border-amber-200 text-amber-600 flex items-center justify-center">
            <AlertTriangle className="w-8 h-8" />
          </div>
          <div className="space-y-2">
            <h1 className="text-2xl sm:text-3xl font-display font-bold text-neutral-950 tracking-tight">
              Property &ldquo;{propertyIdOrSlug}&rdquo; Not Found
            </h1>
            <p className="text-sm text-neutral-500 font-normal max-w-md mx-auto">
              We couldn&apos;t find this specific property identifier in the current verified registry. Explore our top verified properties below:
            </p>
          </div>

          {/* Quick jump to available properties */}
          <div className="w-full grid grid-cols-1 sm:grid-cols-2 gap-3 text-left">
            {allAvailableProperties.slice(0, 4).map((prop) => {
              const mapped = mapToWhitelistedProject(prop);
              return (
                <div
                  key={mapped.id}
                  onClick={() => onNavigateProperty(mapped.id)}
                  className="p-4 bg-white rounded-2xl border border-neutral-200 hover:border-blue-500 hover:shadow-md transition-all cursor-pointer flex items-center justify-between group"
                >
                  <div className="space-y-1">
                    <div className="text-[10px] font-mono font-bold text-blue-600 uppercase">
                      {mapped.builder}
                    </div>
                    <div className="text-sm font-bold text-neutral-950 group-hover:text-blue-600 transition-colors">
                      {mapped.projectName}
                    </div>
                    <div className="text-xs text-neutral-500">
                      {mapped.locality}, {mapped.area}
                    </div>
                  </div>
                  <ArrowRight className="w-4 h-4 text-neutral-400 group-hover:text-blue-600 group-hover:translate-x-1 transition-all shrink-0 ml-2" />
                </div>
              );
            })}
          </div>

          <button
            onClick={onBack}
            className="px-6 py-3 bg-neutral-950 text-white rounded-xl text-xs font-semibold hover:bg-neutral-800 transition-colors cursor-pointer flex items-center space-x-2 shadow-xs"
          >
            <ArrowLeft className="w-4 h-4" />
            <span>Return to Property Explorer</span>
          </button>
        </main>
      </div>
    );
  }

  const p = mapToWhitelistedProject(rawProperty);

  const isSavedComputed =
    isSaved ||
    savedHomes.some(
      (h) =>
        h.propertyName?.toLowerCase() === (p.projectName || "").toLowerCase() ||
        h.id === p.id
    );

  const handleToggleSave = () => {
    if (onSaveProperty) {
      onSaveProperty(rawProperty);
    } else if (isSavedComputed && onRemoveSaved) {
      onRemoveSaved(p.id);
      showToast(`Removed ${p.projectName} from saved properties`, "info");
    } else if (onSaveHome) {
      onSaveHome(rawProperty as PremiumProperty);
      showToast(`Saved ${p.projectName} to collection`, "success");
    }
  };

  const handleShare = () => {
    if (navigator.clipboard) {
      navigator.clipboard.writeText(window.location.href);
      showToast(`Share link copied for ${p.projectName}`, "info");
    }
  };

  return (
    <div className="min-h-screen bg-[#FAFAFC] font-sans antialiased text-neutral-900 pb-28">
      {/* Top Fixed Header */}
      <header className="sticky top-0 z-40 bg-white/90 backdrop-blur-md border-b border-neutral-200/80 px-6 py-4 flex items-center justify-between">
        <button
          onClick={onBack}
          className="flex items-center space-x-2 text-neutral-700 hover:text-neutral-950 font-bold text-xs transition-colors cursor-pointer"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Back to Projects</span>
        </button>

        <div className="flex items-center space-x-2">
          <button
            onClick={handleToggleSave}
            className={`p-2 rounded-full border transition-all cursor-pointer ${
              isSavedComputed
                ? "bg-red-600 text-white border-red-500"
                : "bg-neutral-100 hover:bg-neutral-200 text-neutral-700 border-neutral-200"
            }`}
            title="Save Property"
          >
            <Heart className={`w-4 h-4 ${isSavedComputed ? "fill-current" : ""}`} />
          </button>

          <button
            onClick={handleShare}
            className="p-2 rounded-full bg-neutral-100 hover:bg-neutral-200 text-neutral-700 border border-neutral-200 transition-all cursor-pointer"
            title="Share"
          >
            <Share2 className="w-4 h-4" />
          </button>
        </div>
      </header>

      {/* Main Page Container */}
      <main className="max-w-4xl mx-auto px-4 sm:px-6 py-8 space-y-8">
        {/* Hero Image Banner */}
        <div className="relative h-64 sm:h-96 w-full rounded-[28px] overflow-hidden bg-slate-800 shadow-lg flex items-center justify-center">
          {p.image ? (
            <img
              src={p.image}
              alt={p.projectName}
              referrerPolicy="no-referrer"
              className="w-full h-full object-cover"
            />
          ) : (
            <Building2 className="w-16 h-16 text-slate-700 opacity-50" />
          )}
          <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/30 to-transparent" />

          {/* Top Overlay Badges */}
          <div className="absolute top-4 inset-x-4 flex items-center justify-between">
            <span className="px-3 py-1 rounded-full bg-emerald-600 text-white text-xs font-mono font-bold shadow-xs flex items-center space-x-1">
              <CheckCircle2 className="w-3.5 h-3.5 text-white" />
              <span>RERA Registered ✓</span>
            </span>

            <span className="px-3 py-1 rounded-full bg-neutral-900/90 text-amber-300 text-xs font-mono font-bold border border-neutral-700/60 shadow-xs flex items-center space-x-1">
              <Star className="w-3.5 h-3.5 fill-amber-300 text-amber-300" />
              <span>Google {p.googleRating}</span>
            </span>
          </div>

          {/* Bottom Overlay Title Info */}
          <div className="absolute bottom-5 inset-x-5 text-white space-y-1">
            <div className="text-xs font-mono font-bold text-blue-300 uppercase tracking-wider">
              {p.builder}
            </div>
            <h1 className="text-2xl sm:text-4xl font-black font-display tracking-tight leading-snug">
              {p.projectName}
            </h1>
            <p className="text-xs sm:text-sm text-neutral-300 flex items-center space-x-1">
              <MapPin className="w-4 h-4 text-neutral-400 shrink-0" />
              <span>{p.locality}, {p.area}</span>
            </p>
          </div>
        </div>

        {/* Whitelisted Sections A through F */}
        <ProjectOverviewContent property={rawProperty} />

        {/* Phase 3 - Per-Project AI Deep Intelligence Assistant */}
        <ProjectAIAssistant project={rawProperty} />
      </main>
    </div>
  );
}
