/**
 * ProjectService - Centralized database access layer for real estate projects
 * Encapsulates Supabase client queries for backend routes with fallback to MASTER_PROJECTS.
 */
import { createClient, SupabaseClient } from "@supabase/supabase-js";
import { SERVER_CONFIG } from "../config";
import { MASTER_PROJECTS } from "../../data";

export class ProjectService {
  private client: SupabaseClient | null = null;

  constructor() {
    const { URL, ANON_KEY } = SERVER_CONFIG.SUPABASE;
    if (URL && ANON_KEY && URL !== "placeholder" && !URL.includes("nasccqkadwmfcajgecfs")) {
      try {
        this.client = createClient(URL, ANON_KEY);
      } catch (err) {
        console.warn("[ProjectService] Failed to initialize Supabase client:", err);
      }
    }
  }

  public isConfigured(): boolean {
    return !!this.client;
  }

  /**
   * Lookup a single project by ID, Name, or Slug
   */
  async getProjectByIdOrName(identifier: string): Promise<any | null> {
    if (!identifier) return null;
    const clean = String(identifier).trim().toLowerCase();

    if (this.client) {
      try {
        // First try exact ID lookup
        const { data: byId, error: errId } = await this.client
          .from("projects")
          .select("*")
          .eq("id", identifier)
          .maybeSingle();

        if (!errId && byId) return byId;

        // Fallback: try case-insensitive name lookup
        const { data: byName, error: errName } = await this.client
          .from("projects")
          .select("*")
          .ilike("name", identifier)
          .maybeSingle();

        if (!errName && byName) return byName;
      } catch (err: any) {
        console.warn("[ProjectService] DB lookup error:", err?.message || err);
      }
    }

    // Master projects in-memory fallback - STRICT EXACT MATCHING ONLY
    const found = MASTER_PROJECTS.find(
      p =>
        p.id.toLowerCase() === clean ||
        p.id.toLowerCase().replace(/^proj-/, "") === clean.replace(/^proj-/, "") ||
        (p.slug && (p.slug.toLowerCase() === clean || p.slug.toLowerCase().replace(/^proj-/, "") === clean.replace(/^proj-/, ""))) ||
        p.name.toLowerCase() === clean ||
        p.name.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, "") === clean.replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, "")
    );

    return found || null;
  }

  /**
   * Fetch all published projects
   */
  async getAllProjects(): Promise<any[]> {
    if (this.client) {
      try {
        const { data, error } = await this.client
          .from("projects")
          .select("*")
          .order("created_at", { ascending: false });

        if (!error && data && data.length > 0) {
          return data;
        }
      } catch (err: any) {
        console.warn("[ProjectService] Fetch all projects error:", err?.message || err);
      }
    }

    return MASTER_PROJECTS;
  }

  /**
   * Create a new project
   */
  async createProject(projectData: any): Promise<any | null> {
    if (!this.client) return null;
    try {
      const { data, error } = await this.client
        .from("projects")
        .insert(projectData)
        .select()
        .single();
        
      if (!error && data) return data;
      if (error) console.error("[ProjectService] Create error:", error.message);
    } catch (err: any) {
      console.warn("[ProjectService] Create project exception:", err?.message || err);
    }
    return null;
  }

  /**
   * Update an existing project
   */
  async updateProject(id: string, projectData: any): Promise<boolean> {
    if (!this.client) return false;
    try {
      const { error } = await this.client
        .from("projects")
        .update(projectData)
        .eq("id", id);
        
      if (!error) return true;
      console.error("[ProjectService] Update error:", error.message);
    } catch (err: any) {
      console.warn("[ProjectService] Update project exception:", err?.message || err);
    }
    return false;
  }

  /**
   * Delete a project
   */
  async deleteProject(id: string): Promise<boolean> {
    if (!this.client) return false;
    try {
      const { error } = await this.client
        .from("projects")
        .delete()
        .eq("id", id);
        
      if (!error) return true;
      console.error("[ProjectService] Delete error:", error.message);
    } catch (err: any) {
      console.warn("[ProjectService] Delete project exception:", err?.message || err);
    }
    return false;
  }

  /**
   * Log unfulfilled searches to ai_reports table so admins can see what users are searching for
   */
  async logFailedSearch(query: string, intent: any): Promise<void> {
    if (!this.client || !query) return;
    try {
      const id = `failed_search_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
      await this.client.from("ai_reports").insert({
        id,
        query,
        report_data: { type: "failed_search", intent }
      });
    } catch (err) {
      console.warn("[ProjectService] Failed to log search:", err);
    }
  }

  /**
   * Search projects based on intent and fuzzy fallback
   */
  async searchProjects(intent: any, originalQuery: string = ""): Promise<any[]> {
    const all = await this.getAllProjects();
    const rawLocality = (intent?.locality || "").trim().toLowerCase();
    const rawBuilder = (intent?.builderName || "").trim().toLowerCase();
    const rawText = (originalQuery || "").trim().toLowerCase();
    const unitType = intent?.unitType ? String(intent.unitType).toLowerCase().replace(/\s/g, "") : null;
    const maxPrice = intent?.maxPriceINR;
    const minPrice = intent?.minPriceINR;

    let filtered = all;

    if (rawLocality) {
      const cleanLoc = rawLocality.replace(/road|junction|hub|east|west|north|south|extension/gi, "").trim() || rawLocality;
      filtered = filtered.filter(p => {
        const loc = (p.locality || p.location || p.city || "").toLowerCase();
        return loc.includes(rawLocality) || loc.includes(cleanLoc);
      });
    }

    if (rawBuilder) {
      filtered = filtered.filter(p => {
        const b = (p.builder_name || p.builder || p.developer || p.name || "").toLowerCase();
        return b.includes(rawBuilder);
      });
    }

    if (unitType) {
      filtered = filtered.filter(p => {
        const units = Array.isArray(p.unit_types) ? p.unit_types.join(" ") : String(p.unit_types || p.configurations || "");
        return units.toLowerCase().replace(/\s/g, "").includes(unitType);
      });
    }

    if (maxPrice && maxPrice > 0) {
      const maxLakhs = maxPrice / 100000;
      filtered = filtered.filter(p => {
        let normMinLakhs = Number(p.min_price_lakhs ?? p.minPriceLakhs ?? 0);
        if (!normMinLakhs && (p.min_price || p.minPrice)) {
          const rawVal = Number(p.min_price || p.minPrice);
          normMinLakhs = rawVal > 10000 ? rawVal / 100000 : rawVal;
        }
        return normMinLakhs > 0 && normMinLakhs <= maxLakhs;
      });
    }

    if (minPrice && minPrice > 0) {
      const minLakhs = minPrice / 100000;
      filtered = filtered.filter(p => {
        let normMaxLakhs = Number(p.max_price_lakhs ?? p.maxPriceLakhs ?? 0);
        if (!normMaxLakhs && (p.max_price || p.maxPrice)) {
          const rawVal = Number(p.max_price || p.maxPrice);
          normMaxLakhs = rawVal > 10000 ? rawVal / 100000 : rawVal;
        }
        if (!normMaxLakhs) {
          let normMin = Number(p.min_price_lakhs ?? p.minPriceLakhs ?? 0);
          if (!normMin && (p.min_price || p.minPrice)) {
            const raw = Number(p.min_price || p.minPrice);
            normMin = raw > 10000 ? raw / 100000 : raw;
          }
          normMaxLakhs = normMin;
        }
        return normMaxLakhs > 0 && normMaxLakhs >= minLakhs;
      });
    }

    // Text search strictly operates on identity, not fuzzy matching
    if (rawText && filtered.length === all.length) {
      const q = rawText.toLowerCase().trim();
      filtered = all.filter(p => {
        const nameMatch = (p.name || p.projectName || "").toLowerCase().includes(q);
        const builderMatch = (p.builder_name || p.builder || "").toLowerCase().includes(q);
        const locMatch = (p.locality || p.location || "").toLowerCase().includes(q);
        return nameMatch || builderMatch || locMatch;
      });
    }

    return filtered;
  }
}

export const projectService = new ProjectService();
